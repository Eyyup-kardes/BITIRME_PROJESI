class User {
  final String id;
  final String email;
  final String fullName;
  final int tcNo;
  final int password;
  final int age;
  double balance;
  String profileImage;

  User({
    required this.id,
    required this.email,
    required this.fullName,
    required this.tcNo,
    required this.password,
    required this.age,
    required this.balance,
    this.profileImage = '',
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'email': email,
    'fullName': fullName,
    'tcNo': tcNo,
    'password': password,
    'age': age,
    'balance': balance,
    'profileImage': profileImage,
  };

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      email: json['email'],
      fullName: json['fullName'],
      tcNo: json['tcNo'],
      password: json['password'],
      age: json['age'],
      balance: json['balance'],
      profileImage: json['profileImage'],
    );
  }


  User copyWith({
    String? id,
    String? email,
    String? fullName,
    int? tcNo,
    int? password,
    int? age,
    double? balance,
    String? profileImage,
  }) {
    return User(
      id: id ?? this.id,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      tcNo: tcNo ?? this.tcNo,
      password: password ?? this.password,
      age: age ?? this.age,
      balance: balance ?? this.balance,
      profileImage: profileImage ?? this.profileImage,
    );
  }
}
