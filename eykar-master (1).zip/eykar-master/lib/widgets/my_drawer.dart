import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/auth_controller.dart';
import '../screens/login_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/setting_screen.dart';
import 'my_snackbar.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({super.key, required this.authController});

  final AuthController authController;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(authController.currentUser.value!.fullName),
              decoration: BoxDecoration(color: Colors.black54),
              currentAccountPicture: CircleAvatar(
                radius: 90,
                backgroundImage:
                authController.currentUser.value!.profileImage.isNotEmpty
                    ? FileImage(
                  File(authController.currentUser.value!.profileImage),
                )
                    : null,
                child:
                authController.currentUser.value!.profileImage.isEmpty
                    ? const Icon(Icons.person, size: 50)
                    : null,
              ),
              accountEmail: Text(authController.currentUser.value!.email),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Ana Sayfa'),
              onTap: () {
                Navigator.pop(context); // Drawer'ı kapat
                // Ana sayfaya yönlendirme kodu eklenebilir
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle),
              title: Text('Profil'),
              onTap: () {
                Navigator.pop(context); // Drawer'ı kapat
                // Profil sayfasına yönlendirme kodu eklenebilir
                Get.to(() => ProfileScreen());
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Ayarlar'),
              onTap: () {
                Navigator.pop(context); // Drawer'ı kapat
                // Ayarlar sayfasına yönlendirme kodu eklenebilir
                Get.to(() => SettingsScreen());
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.exit_to_app),
              title: Text('Çıkış Yap'),
              onTap: () {
                Navigator.pop(context); // Drawer'ı kapat
                showMySnack(
                  'Çıkış Başarılı',
                  'Çıkış Başarılı Şekilde Gerçekleşti',
                  true,
                );
                Get.offAll(() => LoginScreen());
                // Çıkış işlemi eklenebilir
              },
            ),
          ],
        ),
      ),
    );
  }
}
