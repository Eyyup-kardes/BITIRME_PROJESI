import 'package:flutter/material.dart';

/// TextFormField Widgetını özelleştirdim. Uygulama boyunca tasarımsal olarak
/// hep aynı görünümde uyumlu olmasını sağladım. Bana lazım olan propertileri burda isimli
/// const ları yazarak kullandım.
class MyTextformfield extends StatelessWidget {
  final TextInputType keyboardType;
  final TextEditingController controller;
  final int? maxLength;
  final String labelText;

  const MyTextformfield({
    super.key,
    this.keyboardType = TextInputType.text,
    required this.controller,
    this.maxLength,
    required this.labelText,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLength: maxLength,
      decoration: InputDecoration(
        labelText: labelText,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(26)),
      ),
    );
  }
}
