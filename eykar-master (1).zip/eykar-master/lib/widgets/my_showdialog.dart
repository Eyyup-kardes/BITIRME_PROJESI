
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/auth_controller.dart';
import 'my_snackbar.dart';


/// Bu Dialog penceresini Login Sayfasında bulunan Kayıtlı Kullanıcılar Butonuna
/// basıldığında ekrana lokalde kayıtlı çıkacak olan User 'larım çıkıyor. Burdan
/// istediğim User seçiyorum ve currentUser olarak onu atamış oluyorum.
void showUserSelectionDialog(BuildContext context) {
  AuthController authController = Get.put(AuthController());
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Kayıtlı Kullanıcılar"),
        content: SizedBox(
          width: double.maxFinite,
          height: Get.size.height / 5,
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Obx(
                      () =>
                  authController.currentUser.value == null
                      ? SizedBox()
                      : TextButton(
                    onPressed: () {
                      Get.back();
                      authController.currentUser.value = null;
                      showMySnack(
                        'Bilgi',
                        'Seçilen kullanıcı iptal edildi',
                        true,
                      );
                    },
                    child: Text(
                      'Seçilen Kullanıcıyı iptal et',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                ),
                Obx(() {
                  return ListView.builder(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: authController.users.length,
                    itemBuilder: (context, index) {
                      final user = authController.users[index];
                      return ListTile(
                        title: Text(user.fullName),
                        subtitle: Text(user.email),
                        trailing: IconButton(
                          onLongPress: () {
                            showMySnack(
                              'Bilgi',
                              'Seçilen ${user.fullName} isimli kullanıcı silme işlemi yapar',
                              true,
                            );
                          },
                          onPressed: () {
                            authController.deleteUser(user);
                            showMySnack('Profil Silindi', user.fullName, true);
                          },
                          icon: Icon(Icons.clear),
                        ),
                        onTap: () {
                          Get.back();
                          authController.currentUser.value = user;
                          authController.saveCurrentUser();
                          showMySnack('Seçilen Profil', user.fullName, true);
                        },
                      );
                    },
                  );
                }),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text("Kapat")),
        ],
      );
    },
  );
}
