import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// Burdaki Fonksiyonu uygulama geneli boyunca kullanıyorum.
/// Kullanıcın yaptığı işlemin sonucuna göre yukarıdan snackbar açarak bilgi mesajı veriyorum.
void showMySnack(String title, String message, bool isCorrect) {
  Get.snackbar(
    title,
    message,
    backgroundColor: isCorrect == false ? Colors.red : Colors.green,
    colorText: isCorrect == false ? Colors.white : Colors.black,
    barBlur: 20,
  );
}
