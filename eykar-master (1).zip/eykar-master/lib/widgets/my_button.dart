import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyButton extends StatelessWidget {
  final void Function()? onPressed;
  final void Function()? onLongPress;
  final Widget child;

  const MyButton({super.key, required this.onPressed, required this.child, this.onLongPress});

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onPressed,
      onLongPress: onLongPress,
      height: 50,
      color: Colors.green.shade900,
      shape: StadiumBorder(),
      minWidth: Get.size.width * 0.7,
      child: child,
    );
  }
}
