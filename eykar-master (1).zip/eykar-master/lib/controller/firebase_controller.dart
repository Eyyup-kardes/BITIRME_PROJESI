import 'package:eykar/models/user.dart' as user_model;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class FirebaseController extends GetxController {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  RxBool isLoading = false.obs;

  // Firebase Giriş Fonksiyonu
  Future<void> login(String email, String password) async {
    isLoading.value = true;
    try {
      // Firebase Authentication ile giriş yapma işlemi
      await auth.signInWithEmailAndPassword(email: email, password: password);
      await firestore.collection('users').doc(auth.currentUser?.uid).get().then(
        (value) {
          // Kullanıcı bilgilerini al
          if (value.exists) {
            // Kullanıcı bilgileri mevcut
            user_model.User.fromJson(value.data()!);
            // Burada kullanıcı bilgilerini işleyebilirsiniz
          } else {
            // Kullanıcı bulunamadı
          }
        },
      );
      // Giriş başarılı olduğunda yapılacak işlemler
    } catch (e) {
      // Hata durumunda yapılacak işlemler
    } finally {
      isLoading.value = false;
    }
  }

  // Firebase Kayıt Fonksiyonu
  Future<void> register(
    String email,
    String password,
    String fullName,
    int tcNo,
    int age,
    double balance,
  ) async {
    isLoading.value = true;
    try {
      // Firebase Authentication ile kayıt olma işlemi
      UserCredential userCredential = await auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      user_model.User newUser = user_model.User(
        id: userCredential.user!.uid,
        email: email,
        fullName: fullName,
        tcNo: tcNo,
        password: int.parse(password),
        // Şifreyi int'e çeviriyoruz
        age: age,
        balance: balance,
      );
      await firestore
          .collection('users')
          .doc(userCredential.user!.uid)
          .set(newUser.toJson());

      // Kayıt başarılı olduğunda yapılacak işlemler
    } catch (e) {
      // Hata durumunda yapılacak işlemler
    } finally {
      isLoading.value = false;
    }
  }

  // Kullanıcı bilgilerini Stream olarak çekme fonksiyonu
  Stream<user_model.User?> getUserStream() {
    return firestore
        .collection('users')
        .doc(auth.currentUser?.uid)
        .snapshots()
        .map((snapshot) {
          if (snapshot.exists) {
            return user_model.User.fromJson(snapshot.data()!);
          } else {
            return null;
          }
        });
  }

  // Para gönderme fonksiyonu
  Future<void> transferMoney(double amount) async {
    isLoading.value = true;
    try {
      // Kullanıcının mevcut bakiyesini al
      DocumentSnapshot userDoc =
          await firestore.collection('users').doc(auth.currentUser?.uid).get();
      if (userDoc.exists) {
        final data = userDoc.data() as Map<String, dynamic>;
        user_model.User currentUser = user_model.User.fromJson(data);
        if (currentUser.balance >= amount) {
          // Yeni kullanıcı nesnesini copyWith ile oluştur
          user_model.User updatedUser = currentUser.copyWith(
            balance: currentUser.balance - amount,
          );
          // Kullanıcının bakiyesini güncelle
          await firestore
              .collection('users')
              .doc(auth.currentUser?.uid)
              .update(updatedUser.toJson());
        } else {
          // Yetersiz bakiye durumu
          Get.snackbar("Hata", "Yetersiz bakiye.");
        }
      }
    } catch (e) {
      // Hata durumunda yapılacak işlemler
      Get.snackbar("Hata", "Bir hata oluştu: $e");
    } finally {
      isLoading.value = false;
    }
  }

  // Para alma fonksiyonu
  Future<void> receiveMoney(double amount) async {
    isLoading.value = true;
    try {
      // Kullanıcının mevcut bakiyesini al
      DocumentSnapshot userDoc =
          await firestore.collection('users').doc(auth.currentUser?.uid).get();
      if (userDoc.exists) {
        final data = userDoc.data() as Map<String, dynamic>;
        user_model.User currentUser = user_model.User.fromJson(data);
        // Yeni kullanıcı nesnesini copyWith ile oluştur
        user_model.User updatedUser = currentUser.copyWith(
          balance: currentUser.balance + amount,
        );
        // Kullanıcının bakiyesini güncelle
        await firestore
            .collection('users')
            .doc(auth.currentUser?.uid)
            .update(updatedUser.toJson());
      }
    } catch (e) {
      // Hata durumunda yapılacak işlemler
      Get.snackbar("Hata", "Bir hata oluştu: $e");
    } finally {
      isLoading.value = false;
    }
  }

  // Kullanıcı şifresini sıfırlama fonksiyonu
  Future<void> resetPassword(String email) async {
    try {
      await auth.sendPasswordResetEmail(email: email);
      Get.snackbar(
        "Başarılı",
        "Şifre sıfırlama bağlantısı e-posta adresinize gönderildi.",
      );
    } catch (e) {
      Get.snackbar("Hata", "Bir hata oluştu: $e");
    }
  }
}
