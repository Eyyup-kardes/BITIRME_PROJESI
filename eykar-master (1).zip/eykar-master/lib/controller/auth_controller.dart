import 'dart:convert';

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';

class AuthController extends GetxController {
  var users = <User>[].obs;
  Rx<User?> currentUser = Rx<User?>(null);

  @override
  void onInit() {
    super.onInit();
    loadUsers();
    loadCurrentUser();
  }

  Future<void> loadUsers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? usersJson = prefs.getString('Kisiler');
    if (usersJson != null) {
      List<dynamic> jsonList = json.decode(usersJson);
      users.value = jsonList.map((e) => User.fromJson(e)).toList();
    }
  }

  Future<void> registerUser(User user) async {
    users.add(user);
    await saveUsers();
  }

  Future<void> saveUsers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String usersJson = json.encode(users.map((e) => e.toJson()).toList());
    await prefs.setString('Kisiler', usersJson);
  }

  Future<void> saveCurrentUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (currentUser.value != null) {
      await prefs.setString('CurrentUser', json.encode(currentUser.value!.toJson()));
    }
  }

  Future<void> loadCurrentUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userJson = prefs.getString('CurrentUser');
    if (userJson != null) {
      currentUser.value = User.fromJson(json.decode(userJson));
    }
  }



  bool login(int tcNo, int password) {
    User? user = users.firstWhereOrNull(
          (user) => user.tcNo == tcNo && user.password == password,
    );
    if (user != null) {
      currentUser.value = user;
      return true;
    }
    return false;
  }

  Future<void> deleteUser(User user) async {
    users.remove(user);
    if (currentUser.value?.email == user.email) {
      currentUser.value = null;
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.remove('CurrentUser');
    }
    await saveUsers();
  }

  // Para transferi metodu
  Future<void> transferMoney(double amount) async {
    if (currentUser.value != null && currentUser.value!.balance >= amount) {
      currentUser.value!.balance -= amount;
      await saveCurrentUser();
      update();
    }
  }
  // Para alma metodu
  Future<void> receiveMoney(double amount) async {
    if (currentUser.value != null) {
      currentUser.value!.balance += amount;
      await saveCurrentUser();
      update();
    }
  }

}
