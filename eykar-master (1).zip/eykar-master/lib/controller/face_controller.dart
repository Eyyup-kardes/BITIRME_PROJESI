import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';

class FaceController extends GetxController {
  var userPhotoPath = ''.obs;
  var savedPhotoPath = ''.obs;
  var currentUser = Rxn<User>();

  var isLoading = false.obs;  // Yükleniyor durumu

  final ImagePicker _imagePicker = ImagePicker();

  @override
  void onInit() {
    super.onInit();
    loadCurrentUser();
  }

  /// Kamera Açılması İçin Alınan İzin
  Future<bool> checkPermissions() async {
    final cameraStatus = await Permission.camera.request();
    return !(cameraStatus.isDenied);
  }

  /// Foto Çekme İşlemi Fonksiyonu
  Future<void> captureImage() async {
    isLoading.value = true;  // Fotoğraf çekme işlemi başladı
    final XFile? image = await _imagePicker.pickImage(source: ImageSource.camera);

    if (image == null) {
      isLoading.value = false; // Fotoğraf çekme işlemi bitti, hata durumunda da false yapıyoruz
      Get.snackbar("Fotoğraf Hatası", "Fotoğraf çekilemiyor.");
      return;
    }

    userPhotoPath.value = image.path;
    await saveUserPhoto(userPhotoPath.value);
    isLoading.value = false; // Fotoğraf çekme işlemi tamamlandı
  }

  Future<void> saveUserPhoto(String photoPath) async {
    if (currentUser.value != null && currentUser.value!.profileImage.isEmpty) {
      currentUser.value!.profileImage = photoPath;
      await saveCurrentUser();
    }
    userPhotoPath.value = photoPath;
    savedPhotoPath.value = photoPath;
  }


  /// Login sayfasında seçilen user'ın bilgilerinin çekildiği fonks.
  Future<void> loadCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString('CurrentUser');
    if (userJson != null) {
      currentUser.value = User.fromJson(json.decode(userJson));
      savedPhotoPath.value = currentUser.value!.profileImage;
    }
  }


  Future<void> saveCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    if (currentUser.value != null) {
      await prefs.setString(
        'CurrentUser',
        json.encode(currentUser.value!.toJson()),
      );
    }
  }

  Future<bool> verifyFace() async {
    if (currentUser.value?.profileImage == null || userPhotoPath.value.isEmpty) {
      return false;
    }
    isLoading.value = true;  // Yüz doğrulama işlemi başladı

    bool result = await _verifyFaceHelper(
      currentUser.value!.profileImage,
      userPhotoPath.value,
    );

    isLoading.value = false;  // Yüz doğrulama tamamlandı
    return result;

  }

  Future<bool> _verifyFaceHelper(String savedPhotoPath, String newPhotoPath) async {
    final savedFaces = await _detectFaces(savedPhotoPath);
    final newFaces = await _detectFaces(newPhotoPath);

    if (savedFaces.isNotEmpty && newFaces.isNotEmpty) {
      final savedFace = savedFaces.first;
      final newFace = newFaces.first;

      final savedFaceFeatures = _extractFaceFeatures(savedFace);
      final newFaceFeatures = _extractFaceFeatures(newFace);

      final similarity = _calculateCosineSimilarity(savedFaceFeatures, newFaceFeatures);
      final distance = _calculateEuclideanDistance(savedFaceFeatures, newFaceFeatures);

      final angleDifferenceX = (savedFace.headEulerAngleX ?? 0.0) - (newFace.headEulerAngleX ?? 0.0);
      final angleDifferenceY = (savedFace.headEulerAngleY ?? 0.0) - (newFace.headEulerAngleY ?? 0.0);
      final angleDifferenceZ = (savedFace.headEulerAngleZ ?? 0.0) - (newFace.headEulerAngleZ ?? 0.0);

      if (kDebugMode) {
        print("Benzerlik Oranı (Cosine): $similarity");
        print("Öklid Mesafesi: $distance");
        print("Baş Açısı Farkı X: $angleDifferenceX");
        print("Baş Açısı Farkı Y: $angleDifferenceY");
        print("Baş Açısı Farkı Z: $angleDifferenceZ");
      }

      if (similarity > 0.80 && distance < 250.0 &&
          angleDifferenceX.abs() < 15 &&
          angleDifferenceY.abs() < 15 &&
          angleDifferenceZ.abs() < 15) {
        return true;
      }
    }
    return false;
  }

  List<double> _extractFaceFeatures(Face face) {
    return [
      face.leftEyeOpenProbability ?? 0.0,
      face.rightEyeOpenProbability ?? 0.0,
      face.smilingProbability ?? 0.0,
      face.headEulerAngleX ?? 0.0,
      face.headEulerAngleY ?? 0.0,
      face.headEulerAngleZ ?? 0.0,
    ];
  }

  double _calculateEuclideanDistance(List<double> vec1, List<double> vec2) {
    double sum = 0.0;
    for (int i = 0; i < vec1.length; i++) {
      sum += pow(vec1[i] - vec2[i], 2);
    }
    return sqrt(sum);
  }

  double _calculateCosineSimilarity(List<double> vec1, List<double> vec2) {
    double dotProduct = 0.0;
    double magnitudeVec1 = 0.0;
    double magnitudeVec2 = 0.0;

    for (int i = 0; i < vec1.length; i++) {
      dotProduct += vec1[i] * vec2[i];
      magnitudeVec1 += pow(vec1[i], 2);
      magnitudeVec2 += pow(vec2[i], 2);
    }

    magnitudeVec1 = sqrt(magnitudeVec1);
    magnitudeVec2 = sqrt(magnitudeVec2);

    return (magnitudeVec1 == 0 || magnitudeVec2 == 0) ? 0.0 : dotProduct / (magnitudeVec1 * magnitudeVec2);
  }

  Future<List<Face>> _detectFaces(String imagePath) async {
    final inputImage = InputImage.fromFile(File(imagePath));
    final faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableClassification: true,
        enableLandmarks: true,
        enableContours: true,
        enableTracking: true,
        performanceMode: FaceDetectorMode.accurate,
      ),
    );

    final faces = await faceDetector.processImage(inputImage);
    await faceDetector.close();
    return faces;
  }
}
