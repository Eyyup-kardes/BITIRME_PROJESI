import 'package:eykar/widgets/my_button.dart';
import 'package:eykar/widgets/my_snackbar.dart';
import 'package:eykar/widgets/my_textformfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/firebase_controller.dart';

class ForgotPasswordScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final FirebaseController firebaseController = Get.put(FirebaseController());

  ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Şifremi Unuttum")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          spacing: 20,
          children: [
            MyTextformfield(
              controller: emailController,
              labelText: 'E-posta Adresi',
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 20),
            MyButton(
              onPressed: () async {
                String email = emailController.text.trim();
                if (email.isNotEmpty) {
                  await firebaseController.resetPassword(email);
                } else {
                  showMySnack(
                    'Hata',
                    'Lütfen geçerli bir e-posta adresi giriniz.',
                    true,
                  );
                }
              },
              child: Text("Şifre Sıfırlama Bağlantısı Gönder"),
            ),
          ],
        ),
      ),
    );
  }
}
