import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ayarlar')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Genel Ayarlar Başlığı
            ListTile(
              leading: Icon(Icons.account_circle),
              title: Text('Hesap Ayarları'),
              onTap: () {
                // Hesap ayarlarına gitme kodu eklenebilir
              },
            ),
            Divider(),

            // Bildirim Ayarları
            ListTile(
              leading: Icon(Icons.notifications),
              title: Text('Bildirim Ayarları'),
              onTap: () {
                // Bildirim ayarlarına gitme kodu eklenebilir
              },
            ),
            Divider(),

            // Dil Ayarları
            ListTile(
              leading: Icon(Icons.language),
              title: Text('Dil Ayarları'),
              onTap: () {
                // Dil ayarları sayfasına gitme kodu eklenebilir
              },
            ),
            Divider(),

            // Gizlilik Politikası
            ListTile(
              leading: Icon(Icons.lock),
              title: Text('Gizlilik Politikası'),
              onTap: () {
                // Gizlilik politikasına gitme kodu eklenebilir
              },
            ),
            Divider(),

            // Çıkış Yap
            ListTile(
              leading: Icon(Icons.exit_to_app),
              title: Text('Çıkış Yap'),
              onTap: () {
                // Çıkış yapma işlemi yapılabilir
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(SnackBar(content: Text('Çıkış yapıldı!')));
              },
            ),
          ],
        ),
      ),
    );
  }
}
