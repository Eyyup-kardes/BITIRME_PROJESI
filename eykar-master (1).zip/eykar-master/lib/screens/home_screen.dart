import 'package:eykar/controller/firebase_controller.dart';
import 'package:eykar/screens/transfer_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:eykar/models/user.dart' as user_model;

import '../controller/auth_controller.dart';
import '../widgets/my_drawer.dart';
import '../widgets/my_snackbar.dart';
import '../widgets/my_textformfield.dart';

class HomeScreen extends StatelessWidget {
  final TextEditingController balanceController = TextEditingController();
  final FirebaseController firebaseController = Get.put(FirebaseController());
  final AuthController authController = Get.put(AuthController());

  HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hoş Geldin ${authController.currentUser.value?.fullName}'),
      ),
      drawer: MyDrawer(authController: authController),
      body: StreamBuilder<user_model.User?>(
        stream: firebaseController.getUserStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator(); // Yükleniyor göstergesi
          }

          if (snapshot.hasData && snapshot.data != null) {
            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  spacing: 20,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(42.0),
                      child: Container(
                        width: Get.size.width,
                        height: Get.size.height * 0.5,
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(26),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey,
                              spreadRadius: 20,
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: Column(
                          spacing: 20,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              'Tüm Varlıklarım',
                              style: TextStyle(fontSize: 28),
                            ),
                            Text(
                              '${snapshot.data!.balance} TL',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 80),
                            ),
                            TextButton(
                              onPressed: () {
                                showMySnack(
                                  'Bilgi',
                                  'Hesabınızda Şuan ${snapshot.data!.balance} TL var',
                                  true,
                                );
                              },
                              child: Text(
                                'Detaylar için Tıkla',
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    MyTextformfield(
                      controller: balanceController,
                      labelText: 'Para Transfer İçin Fiyat Girin',
                      keyboardType: TextInputType.number,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        MaterialButton(
                          onPressed: () async {
                            Get.to(() => TransferScreen());
                          },
                          minWidth: Get.size.width * 0.3,
                          height: 50,
                          color: Colors.blue.shade900,
                          shape: StadiumBorder(),
                          child: Text('Parayı Transfer Et'),
                        ),
                        MaterialButton(
                          onPressed: () async {
                            if (balanceController.text.trim().isNotEmpty) {
                              double amount =
                                  double.tryParse(
                                    balanceController.text.trim(),
                                  ) ??
                                  0;
                              if (amount > 0) {
                                // Para alma
                                await firebaseController.receiveMoney(amount);
                                await authController.receiveMoney(amount);
                                authController.currentUser.refresh();
                                showMySnack(
                                  'Başarıyla Alındı',
                                  '$amount TL hesabınıza eklendi.',
                                  true,
                                );
                              }
                            }
                          },
                          minWidth: Get.size.width * 0.3,
                          height: 50,
                          color: Colors.green.shade900,
                          shape: StadiumBorder(),
                          child: Text('Parayı Transfer Al'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          } else {
            return Text(
              '0 TL',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 80),
            );
          }
        },
      ),
    );
  }
}
