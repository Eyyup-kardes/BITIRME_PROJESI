import 'dart:io';
import 'package:eykar/controller/firebase_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:eykar/models/user.dart' as user_model;
import '../controller/auth_controller.dart';
import '../widgets/my_snackbar.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final FirebaseController firebaseController = Get.put(FirebaseController());
   final AuthController authController = Get.put(AuthController());
    return Scaffold(
      appBar: AppBar(title: Text(authController.currentUser.value!.fullName)),
      body: StreamBuilder<user_model.User?>(
        stream: firebaseController.getUserStream(),
        builder: (context, snapshot) {

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data == null) {
            return Center(child: Text("Kullanıcı bilgileri bulunamadı."));
          }
          final user = snapshot.data!;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    child: Column(
                      spacing: 20,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Center(
                          child: CircleAvatar(
                            radius: 160,
                            backgroundImage:
                            authController
                                .currentUser
                                .value!
                                .profileImage
                                .isNotEmpty
                                ? FileImage(
                              File(
                                authController
                                    .currentUser
                                    .value!
                                    .profileImage,
                              ),
                            )
                                : null,
                            child:
                            authController.currentUser.value!.profileImage.isEmpty
                                ? const Icon(Icons.person, size: 50)
                                : null,
                          ),
                        ),
                        ListTile(
                          title: Text('Adı Soyadı'),
                          subtitle: Text(
                            user.fullName,
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),

                        ListTile(
                          title: Text('Toplam Para'),
                          subtitle: Text(
                            '${user.balance.toStringAsFixed(2)} TL',
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        ),


                        ListTile(
                          title: Text('TC Kimlik No'),
                          subtitle: Text(
                            user.tcNo.toString(),
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        ),

                        ListTile(
                          title: Text('E mail'),
                          subtitle: Text(
                            user.email,
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        ),

                        ListTile(
                          title: Text('Yaş'),
                          subtitle: Text(
                            user.age.toString(),
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        ),

                        ListTile(
                          title: Text('Şifre'),
                          subtitle: Text(
                           user.password.toString(),
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                ListTile(
                  tileColor: Colors.black54,
                  leading: Icon(Icons.exit_to_app),
                  trailing: Icon(Icons.exit_to_app),
                  title: Text('Çıkış Yap',textAlign: TextAlign.center,style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold
                  ),),
                  onTap: () {
                    Navigator.pop(context); // Drawer'ı kapat
                    showMySnack(
                      'Çıkış Başarılı',
                      'Çıkış Başarılı Şekilde Gerçekleşti',
                      true,
                    );
                    Get.offAll(() => LoginScreen());
                    // Çıkış işlemi eklenebilir
                  },
                ),
              ],
            ),
          );
        }
      ),
    );
  }
}
