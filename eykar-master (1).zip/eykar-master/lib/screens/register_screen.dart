import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';

import '../controller/auth_controller.dart';
import '../controller/face_controller.dart';
import '../controller/firebase_controller.dart';
import '../models/user.dart';
import '../widgets/my_button.dart';
import '../widgets/my_snackbar.dart';
import '../widgets/my_textformfield.dart';
import 'face_read_screen.dart';
import 'login_screen.dart';

class RegisterScreen extends StatelessWidget {
  final FirebaseController firebaseController = Get.put(FirebaseController());
  final AuthController authController = Get.put(AuthController());
  final FaceController faceController = Get.put(FaceController());
  final TextEditingController emailController = TextEditingController();
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController tcNoController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController ageController = TextEditingController();

  RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Kayıt Ol")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          spacing: 20,
          children: [
            MyTextformfield(
              controller: emailController,
              labelText: "E-Posta",
              keyboardType: TextInputType.emailAddress,
            ),
            MyTextformfield(
              controller: fullNameController,
              labelText: "Ad Soyad",
            ),
            MyTextformfield(
              controller: tcNoController,
              labelText: "TC Kimlik No",
              keyboardType: TextInputType.number,
              maxLength: 11,
            ),
            MyTextformfield(
              controller: ageController,
              labelText: "Yaş",
              keyboardType: TextInputType.number,
              maxLength: 3,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Şifre'),
                Pinput(
                  controller: passwordController,
                  length: 6,
                  obscuringCharacter: '*',
                  obscuringWidget: Text('*', style: TextStyle(fontSize: 30)),
                  pinAnimationType: PinAnimationType.rotation,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  onCompleted: (pin) {
                    goFaceScreen();
                  },
                ),
              ],
            ),

            SizedBox(height: 20),
            MyButton(
              onPressed: () {
                goFaceScreen();
              },
              child: Text("Kayıt Ol"),
            ),
          ],
        ),
      ),
    );
  }

  void goFaceScreen() async {
    if (emailController.text.trim().isNotEmpty &&
        fullNameController.text.trim().isNotEmpty &&
        tcNoController.text.trim().isNotEmpty &&
        passwordController.text.trim().isNotEmpty &&
        ageController.text.trim().isNotEmpty) {
      User newUser = User(
        id: '',
        email: emailController.text.trim(),
        fullName: fullNameController.text.trim(),
        tcNo: int.tryParse(tcNoController.text.trim()) ?? 0,
        password: int.tryParse(passwordController.text.trim()) ?? 0,
        age: int.tryParse(ageController.text.trim()) ?? 0,
        balance: 0.0,
        profileImage: '',
      );
      // FaceReadScreen'den fotoğrafı al
      final result = await Get.to(
        () => FaceReadScreen(isRegister: true, user: newUser),
      );

      if (result != null && result is String) {
        newUser.profileImage = result; // Fotoğrafı ekle
        authController.currentUser.value = newUser;
        await authController.saveCurrentUser();
        // Firebase'e kayıt işlemi
        await firebaseController.register(
          emailController.text.trim(),
          passwordController.text.trim(),
          fullNameController.text.trim(),
          int.tryParse(tcNoController.text.trim()) ?? 0,
          int.tryParse(ageController.text.trim()) ?? 0,
          0.0,
        );
      } else {
        Get.snackbar("Hata", "Yüz tanıma tamamlanmadı.");
        return;
      }

      authController.registerUser(newUser);
      showMySnack('Kayıt Başarılı', 'Kullanıcı Kaydı Başarılı Yapıldı', true);
      // Yüz doğrulama sayfasına geçiş
      Get.offAll(() => LoginScreen());
    } else {
      showMySnack(
        'Eksik Kayıt',
        'Kullanıcı bilgilerinde eksik olan yer var. Lütfen hepsini dolduralım',
        false,
      );
    }
  }
}
