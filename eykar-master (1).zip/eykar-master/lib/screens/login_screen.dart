import 'dart:io';
import 'package:eykar/controller/firebase_controller.dart';
import 'package:eykar/screens/forgot_screen.dart';
import 'package:eykar/screens/register_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';

import '../controller/auth_controller.dart';
import '../widgets/my_button.dart' show MyButton;
import '../widgets/my_showdialog.dart';
import '../widgets/my_snackbar.dart';
import '../widgets/my_textformfield.dart';
import 'face_read_screen.dart';
import 'home_screen.dart';

class LoginScreen extends StatelessWidget {
  final FirebaseController firebaseController = Get.put(FirebaseController());
  final AuthController authController = Get.put(AuthController());
  final TextEditingController tcKimlikController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Obx(() {
          return Text(
            "Merhaba ${authController.currentUser.value?.fullName ?? "Hadi Giriş Yapalım"}",
          );
        }),
        actions: [
          Obx(() {
            return authController.currentUser.value != null
                ? SizedBox()
                : IconButton(
                  onPressed: () {
                    showUserSelectionDialog(context);
                  },
                  icon: Icon(Icons.person_add_alt_1_rounded),
                );
          }),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          spacing: 20,
          children: [
            Obx(
              () =>
                  authController.currentUser.value != null
                      ? Stack(
                        children: [
                          CircleAvatar(
                            radius: 100,
                            backgroundImage: FileImage(
                              File(
                                authController.currentUser.value!.profileImage,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 0,
                            top: 0,
                            child: GestureDetector(
                              onTap: () => showUserSelectionDialog(context),
                              onLongPress:
                                  () => showMySnack(
                                    'Bilgi',
                                    'Kayıtlı Kullanıcıların Bulunduğu Liste',
                                    true,
                                  ),
                              child: CircleAvatar(
                                backgroundColor: Colors.green.shade900,
                                child: Icon(
                                  Icons.person_search_rounded,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                      : SizedBox(),
            ),
            Obx(() {
              return authController.currentUser.value != null
                  ? Text(
                    authController.currentUser.value!.fullName,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                  )
                  : MyTextformfield(
                    controller: tcKimlikController,
                    labelText: "TC Kimlik No",
                    keyboardType: TextInputType.number,
                    maxLength: 11,
                  );
            }),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              spacing: 10,
              children: [
                Text('Şifre'),
                Pinput(
                  controller: passwordController,
                  length: 6,
                  obscuringCharacter: '*',
                  obscuringWidget: Text('*', style: TextStyle(fontSize: 30)),
                  obscureText: true,
                  pinAnimationType: PinAnimationType.rotation,
                  keyboardType: TextInputType.number,
                  onCompleted: (pin) {
                    goFaceScreen();
                  },
                ),
              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Get.to(() => ForgotPasswordScreen());
                  },
                  child: Text('Şifremi Unuttum!'),
                ),
              ],
            ),

            MyButton(
              onPressed: () {
                goFaceScreen();
              },
              child: Text("Giriş Yap"),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Henüz hesabın yoksa'),
                TextButton(
                  onPressed: () {
                    Get.to(() => RegisterScreen());
                  },
                  child: Text("Kayıt Ol"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void goFaceScreen() async {
    int? tcNo =
        authController.currentUser.value == null
            ? int.tryParse(tcKimlikController.text.trim())
            : authController.currentUser.value!.tcNo;
    int? password =
        passwordController.text.trim().isEmpty
            ? null
            : int.tryParse(passwordController.text.trim());

    if (tcNo != null && password != null) {
      if (authController.login(tcNo, password)) {
        Get.to(
          () => FaceReadScreen(
            isRegister: false,
            user: authController.currentUser.value!,
          ),
        )?.then((faceResult) async {
          if (faceResult == true) {
            await firebaseController.login(
              authController.currentUser.value!.email,
              passwordController.text.trim(),
            );
            // Yüz doğrulaması başarılıysa HomeScreen'e yönlendir
            showMySnack("Giriş Onaylandı", "Yüz doğrulama başarılı", true);

            Get.off(() => HomeScreen());
          } else {
            // Yüz doğrulaması başarısızsa hata göster
            showMySnack("Giriş Başarısız", "Yüz tanıma başarısız oldu", false);
          }
        });
      } else {
        showMySnack("Hata", "Geçersiz bilgiler", false);
        passwordController.clear();
      }
    } else {
      showMySnack(
        "Eksik Bilgi",
        "Lütfen Tc Kimlik ve Şifrenizi Eksiksiz Giriniz",
        false,
      );
    }
  }
}
