import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/face_controller.dart';
import '../models/user.dart';
import '../widgets/my_button.dart';
import '../widgets/my_snackbar.dart';

class FaceReadScreen extends StatelessWidget {
  final User user;
  final bool isRegister;

  const FaceReadScreen({
    super.key,
    required this.user,
    required this.isRegister,
  });

  @override
  Widget build(BuildContext context) {
    final FaceController faceController = Get.put(FaceController());

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                spacing: 30,
                children: [
                  SizedBox(height: 20),

                  // Kullanıcı Fotoğrafı Önizlemesi
                  _buildUserPhotoPreview(faceController),

                  // Fotoğraf Çekme Butonu
                  _buildCaptureButton(faceController),

                  // Kayıt veya Giriş İşlemi
                  _buildActionButton(faceController),

                  // Yükleniyor göstergesi
                  Obx(() {
                    return faceController.isLoading.value
                        ? CircularProgressIndicator()
                        : SizedBox.shrink();
                  }),
                ],
              ),
              _buildInfoButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCaptureButton(FaceController faceController) {
    return Obx(() {
      return faceController.userPhotoPath.value.isNotEmpty
          ? SizedBox()
          : MyButton(
        onPressed: () async {
          await faceController.captureImage();
        },
        child: const Text('Fotoğraf Çek'),
      );
    });
  }

  Widget _buildUserPhotoPreview(FaceController faceController) {
    return Obx(() {
      return faceController.userPhotoPath.value.isEmpty
          ? Container(
        height: 160,
        width: Get.size.width * 0.7,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade900,
              blurRadius: 20,
              spreadRadius: 10,
            ),
          ],
        ),
        child: Center(child: const Text('Henüz fotoğraf çekilmedi.')),
      )
          : Stack(
        children: [
          CircleAvatar(
            radius: 140,
            backgroundImage:
            faceController.userPhotoPath.value.isNotEmpty
                ? FileImage(File(faceController.userPhotoPath.value))
                : AssetImage('assets/avatar1.png') as ImageProvider,
          ),
          Positioned(
            right: 0,
            bottom: 0,
            child: GestureDetector(
              onTap: () => faceController.captureImage(),
              onLongPress:
                  () => showMySnack(
                'Bilgi',
                'Kayıtlı Kullanıcıların Bulunduğu Liste',
                true,
              ),
              child: CircleAvatar(
                backgroundColor: Colors.green.shade900,
                child: Icon(Icons.camera_alt_rounded, color: Colors.white),
              ),
            ),
          ),
        ],
      );
    });
  }

  Widget _buildActionButton(FaceController faceController) {
    return Obx(() {
      return faceController.userPhotoPath.value.isNotEmpty
          ? MyButton(
        onPressed: () async {
          if (isRegister) {
            await _registerUser(faceController);
          } else {
            await _verifyFace(faceController);
          }
        },
        child: Text(isRegister ? 'Kayıt Ol' : 'Yüz Doğrulama Yap'),
      )
          : const SizedBox();
    });
  }

  Future<void> _registerUser(FaceController faceController) async {
    await faceController.saveUserPhoto(faceController.userPhotoPath.value);
    user.profileImage = faceController.userPhotoPath.value;
    await faceController.saveCurrentUser();
    Get.back(result: user.profileImage);
  }

  Future<void> _verifyFace(FaceController faceController) async {
    bool faceMatch = await faceController.verifyFace();
    if (faceMatch) {
      Get.back(result: true);
    } else {
      Get.snackbar("Hata", "Yüz doğrulama başarısız.");
    }
  }

  Widget _buildInfoButton() {
    return Column(
      children: [
        MaterialButton(
          shape: StadiumBorder(),
          onPressed: () {
            showMySnack(
              'Bilgi',
              'Kamerayı yüzünüze tam karşıda olacak şekilde tutun ve fotoğrafınızı çekin. Daha sonra onaylayın.',
              true,
            );
          },
          child: const Text('Yüz Tarama Alanı Hakkında Bilgi Al'),
        ),
        SizedBox(height: 20),
      ],
    );
  }
}
