import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:eykar/models/user.dart' as user_model;

class TransferScreen extends StatelessWidget {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final TextEditingController amountController = TextEditingController();

  TransferScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kullanıcıya Para Gönder'),
        actions: [
      StreamBuilder<DocumentSnapshot>(
      stream: firestore
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser?.uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: CircularProgressIndicator(color: Colors.white),
          );
        }
        if (snapshot.hasData && snapshot.data != null) {
          final userData = snapshot.data!.data() as Map<String, dynamic>;
          final currentBalance = userData['balance'] ?? 0.0;
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                '${currentBalance.toStringAsFixed(2)} TL',
                style: TextStyle(fontSize: 18),
              ),
            ),
          );
        }
        return SizedBox();
      },
    ),
    ],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: firestore.collection('users').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('Kayıtlı kullanıcı bulunamadı.'));
                }

                final currentUserId = FirebaseAuth.instance.currentUser?.uid;


                final users = snapshot.data!.docs
                // Kendi hesabını filtrele
                    .where((doc) => doc.id != currentUserId)
                    .map((doc) {
                  return user_model.User.fromJson(
                    doc.data() as Map<String, dynamic>,
                  );
                }).toList();

                if (users.isEmpty) {
                  return Center(child: Text('Kayıtlı başka kullanıcı bulunamadı.'));
                }

                return ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    final user = users[index];
                    return ListTile(
                      title: Text(user.fullName),
                      subtitle: Text('Bakiye: ${user.balance} TL'),
                      onTap: () => _showTransferDialog(context, user),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showTransferDialog(BuildContext context, user_model.User recipient) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Para Gönder: ${recipient.fullName}'),
          content: TextField(
            controller: amountController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Gönderilecek Tutar'),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('İptal'),
            ),
            TextButton(
              onPressed: () async {
                double amount = double.tryParse(amountController.text.trim()) ?? 0;
                if (amount > 0) {
                  await _transferMoney(recipient, amount);
                  Get.back();
                } else {
                  Get.snackbar('Hata', 'Geçerli bir tutar giriniz.');
                }
              },
              child: Text('Gönder'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _transferMoney(user_model.User recipient, double amount) async {
    try {
      // Gönderenin bakiyesini güncelle
      DocumentSnapshot senderDoc = await firestore
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser?.uid)
          .get();
      if (senderDoc.exists) {
        final senderData = senderDoc.data() as Map<String, dynamic>;
        user_model.User sender = user_model.User.fromJson(senderData);

        if (sender.balance >= amount) {
          amountController.clear();
          Get.back();
          Get.snackbar('Başarılı', '${recipient.fullName} adlı kullanıcıya $amount TL gönderildi.');

          // Gönderenin bakiyesini düşür
          user_model.User updatedSender = sender.copyWith(
            balance: sender.balance - amount,
          );
          await firestore
              .collection('users')
              .doc(FirebaseAuth.instance.currentUser?.uid)
              .update(updatedSender.toJson());

          // Alıcının bakiyesini artır
          user_model.User updatedRecipient = recipient.copyWith(
            balance: recipient.balance + amount,
          );
          await firestore
              .collection('users')
              .doc(recipient.id) // Alıcının ID'si
              .update(updatedRecipient.toJson());

        } else {
          Get.snackbar('Hata', 'Yetersiz bakiye.');
        }
      }
    } catch (e) {
      Get.snackbar('Hata', 'Bir hata oluştu: $e');
    }
  }
}